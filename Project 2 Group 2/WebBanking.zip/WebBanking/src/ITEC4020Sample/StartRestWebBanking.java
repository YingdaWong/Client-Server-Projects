package ITEC4020Sample;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.NumberFormat;
import java.util.Locale;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.MediaType;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientHandlerException;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.UniformInterfaceException;
import com.sun.jersey.api.client.WebResource;




/**
 * Servlet implementation class StartRestWebBanking
 * ITEC4020 This is the twin of the StartWebBanking servlet. The difference here is that 
 * instead of calling the performDBDeposit or the performDBWithdrawal methods in the 
 * DBDeposit and DBWithdrawal classes respectively, we issue a rest call to the
 * RestDeposit or RestWithdrawal classes (which have been properly annotated and comply
 * with the JAX-RS protocol). These REST calls depending on the URL path call the 
 * the DoRestDeposit or the DoRestWithdrawal in the DBDeposit and DBWithdrawal classes 
 * respectively
 */
@WebServlet("/StartRestWebBanking")
public class StartRestWebBanking extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StartRestWebBanking() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		String value = request.getParameter("amountValue"); 
		String userName = (String) request.getSession().getAttribute("uname");
		String thePin = (String) request.getSession().getAttribute("upass");
		String accType = (String) request.getSession().getAttribute("accType");
		String transType = (String) request.getSession().getAttribute("transType");
        int acc = -1;
        int trans = -1;
        WebResource aResource;
        ClientResponse restResponse = null;
        String accTypeSpecifier = null;
        
        /*
         * ITEC 4020 Remember that the card number servers as a user's user name
         * and the pin as its password. As these are collected as strings we convert 
         * them to integers.
         */
		int cardNo = Integer.parseInt(userName);
		int pin = Integer.parseInt(thePin);
		int amount = Integer.parseInt(value);
		
		// Set the flags as integers to be passed to the URL of REST call
		
		if(accType.equals("Chequing")) 
    	{
			accTypeSpecifier = "Chequing";
    		acc = 1;
    	}
	
    	if(accType.equals("Savings")) 
    	{
    		accTypeSpecifier = "Savings";
    		acc = 2;
    	}
	
    	if(transType.equals("Withdrawal")) 
    	{
    		trans = 1;
    		Client client = Client.create();
    		
    		// ITEC 4020 Do the REST call for withdrawal 
    		aResource = client
    		   .resource("http://localhost:8080/WebBanking/rest/withdrawal/query?cardNumber="+cardNo
    				      +"&pin="+ pin +"&accType=" + acc  +"&amount=" + amount);

    	    restResponse = aResource.accept(MediaType.APPLICATION_JSON)
                       .get(ClientResponse.class);
    	}
    	
    	if(transType.equals("Deposit")) 
    	{
    		trans = 2;
    		Client client = Client.create();
    		
    		// ITEC 4020 Do the REST call for deposit
    		aResource = client
    		   .resource("http://localhost:8080/WebBanking/rest/deposit/query?cardNumber="+cardNo
    				      +"&pin="+ pin +"&accType=" + acc  +"&amount=" + amount);

    		// formulate the response with a JSON payload 
    	    restResponse = aResource.accept(MediaType.APPLICATION_JSON)
                       .get(ClientResponse.class);
    	}
	
	
		try {
			    // create a JSON object out of the response obtained
				JSONObject resObj;
				resObj = (JSONObject)new JSONParser().parse(restResponse.getEntity(String.class));
			
			    // get the information of ownerID and balance fields from the JSON object
				Long ownID = (Long) resObj.get("ownerID");
				Long bal = (Long) resObj.get("balance");
			
				NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(Locale.CANADA); 
				

				// create a new output writer
				PrintWriter out = response.getWriter();
				// write the HTML page to be displayed as a result
				String title = "The Results of the Transaction Using Restful Call";
				String docType =
		         "<!doctype html public \"-//w3c//dtd html 4.0 " + "transitional//en\">\n";
		         
				out.println(docType +
		         "<html>\n" +
		            "<head><title>" + title + "</title></head>\n" +
		            "<body bgcolor = \"#f0f0f0\">\n" +
		               "<h1 align = \"center\">" + title + "</h1>\n" +
		               "<ul>\n" +
		               "  <li><b>Card Number</b>: "
		                  + cardNo + "\n" +
		                  "  <li><b>Account Number</b>: "
		                  + ownID + " (" + accTypeSpecifier + ")" +"\n" +
		                  "  <li><b>New Balance</b>: "
		                  + currencyFormat.format(bal) + "\n" +
		               "</ul>\n" +
		            "</body>" +
		         "</html>"
		      );
			
			
			
		} catch (ClientHandlerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UniformInterfaceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
