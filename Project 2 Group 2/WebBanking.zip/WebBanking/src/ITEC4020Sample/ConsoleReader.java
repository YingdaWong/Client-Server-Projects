package ITEC4020Sample;

import java.util.Scanner;

/*
 * ITEC 4020 This is a class which one can use to collect information from the 
 * console in order to directly call the performDBDeposit method in the DBDeposit
 * class, or the performDBWithdrawal method in the DBWithdrawal class. We have this 
 * class in order to test the JDBC use of the system without using servlets 
 */
public class ConsoleReader {
	
	public TransactionInfo getTransactionInfo() {
	
	Scanner input = new Scanner(System.in);
	
	TransactionInfo userInput = new TransactionInfo();

	// sends output to the socket 
	
	 System.out.print("Enter cardNo: ");
	 int cardNo = input.nextInt();
	// System.out.print("\n ");
	 
    System.out.print("Enter pin: ");
	 int pin = input.nextInt();
	// System.out.print("\n ");     
	 
    System.out.print("Enter account Type (1 for Chequing, 2 for Savings, 3 for Investments: ");
	 int account = input.nextInt();
	// System.out.print("\n ");
	 
	 System.out.print("Enter transaction Type (1 for Withdrawal, 2 for Deposit: ");
	 int transactionType = input.nextInt();
	// System.out.print("\n ");
	 
	 
    System.out.print("Enter amount: ");
	 int amount = input.nextInt();
	// System.out.print("\n ");
	 
		userInput.setCardNumber(cardNo);
		userInput.setPin(pin);
		userInput.setAccountType(account);
		userInput.setTransactionType(transactionType);
		userInput.setAmount(amount);

	return userInput;
	}
}
	

