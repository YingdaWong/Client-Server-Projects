package ITEC4020Sample;

import transactions.*;

/*
 * This is a simple client class to test the pure JDBC without the use of servlets. 
 * It utilizes a Console reader to get information form the user through the console
 * and calls the performDBDeposit or PerformDBWithdrawal methods accordingly
 */
public class SimpleJDBCBanking {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Welcome to IT Bank \n");
		
		TransactionInfo transInfo;
		
		ConsoleReader aReader = new ConsoleReader();
		
		transInfo = aReader.getTransactionInfo();
		
		System.out.println("Transaction starting\n");
		
		
		if (transInfo.getTransactionType() == 1) {
			DBWithdrawal aDBWithdrawal = new DBWithdrawal();
			aDBWithdrawal.performDBWithdrawal(transInfo.getCardNumber(), 
					                    transInfo.getPin(), 
					                    transInfo.getAccountType(), 
					                    transInfo.getAmount());
			
		}
		
		if (transInfo.getTransactionType() == 2) {
			DBDeposit aDBDeposit = new DBDeposit();
			aDBDeposit.performDBDeposit(transInfo.getCardNumber(), 
					                    transInfo.getPin(), 
					                    transInfo.getAccountType(), 
					                    transInfo.getAmount());
			
		}
			
		
		
		System.out.println("Transaction completed\n");
		
		

	}

}
