package transactions;


import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import DataBase.AccountEntry;

/*
 * ITEC 4020 This is the RestDeposit Class whuch is annotated by a the path /deposit
 * Its method DorestDeposit has path annoitation /query and responds to a GET Restful 
 * Request. The whole call is possible by the use of the Jax-RS framework imported 
 * by javax.ws.rs.*
 * The invocation comes from the method DoGet method of the StartRestWebBanking servlet.
 * Note that once yoi have your Tomcat Running you can open a browser (e.g. Chrome)
 * and directly call to 
 * http://localhost:8080/WebBanking/rest/deposit/query?cardNumber=1&pin=42&accType=1&amount=200
 * to deposit 200 $ to chequing account corresponding to card number 1 and pin 42
 */

@Path("/deposit")
public class RestDeposit {
		@GET
		@Path("/query")
		public Response DoRestDeposit(
				// here are the method parameters annotated to respond to a Rest call
				@QueryParam("cardNumber") Integer cardNo  , 
				@QueryParam("pin") Integer pin,
				@QueryParam("accType") Integer accountType,
				@QueryParam("amount") Integer amount) {
		  
 
			    //set the result initially to null
				AccountEntry result = null;
				
				// create a new DBDeposit object

				DBDeposit aDBDeposit = new DBDeposit();
				
				// call the performDBDeposit method on the DBDeposit object and get
				// the result as an AccounEntry object

				result = aDBDeposit.performDBDeposit(cardNo, pin, accountType, amount);

				// Create a string jsonResult variable to store the result as a Json 
				// string. Initiallize it to null
				String jsonResult = null;

			//Transorm the AccountEntry result object object to a JSON string
			// and store it to the jsonResult variable
				try {
				
					ObjectMapper mapper = new ObjectMapper();
					jsonResult = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(result);
				} catch (JsonProcessingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				// Create the Response to the Rest call with HTTP status 200 OK. 
				// See the StartRestWebbanking how this is 
				// response is handled (the Json paylod is extracred and printed as an HTML page)
				return Response.status(200).entity(jsonResult).build();
}


	 
}
