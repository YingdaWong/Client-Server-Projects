package transactions;

import DataBase.*;
import DataBase.BankDatabase.AccountNotFound;

/*
 * ITEC 4020 Here is the class the performs the Deposit through its performDBDeposit
 * method
 */
public class DBDeposit { 
	
	public AccountEntry performDBDeposit(int cardNumber, int pin, int accountType, int amount) {
		AccountEntry account = null;
		int result = -1;
        BankDatabase database = new BankDatabase();
        DBCredentialsChecker aChecker = new DBCredentialsChecker();
        Boolean checkValue = false;
        
        
		
		try {
			/*
			 * ITEC 4020 Here you get the account details given the cardNumber and 
			 * the account type. The getAccountInfo method returns an object 
			 * of type AccountEntry that contains all the information of the sepcific
			 * acccount such as its ID, balances etc. See the BankDataBase class for the 
			 * getAccountInfo method and the AccountEntry class for the AccountEntry
			 * object structure
			 */
			account = database.getAccountInfo(cardNumber, accountType);
		} catch (AccountNotFound e) {
			System.out.println("Invalid account type");
			return null;
		}

		/*
		 * ITEC 4020 Here check whether the cardNumber and pin provided by the user 
		 * in the Login Servlet are the ones matching at the Data Base
		 */
		checkValue = aChecker.performDBCredentialsCheck(cardNumber, accountType, pin);
		
	    if(checkValue) {

	    	
			// ITEC 4020 if the provided card number and pin match the ones in the DB Renew balance
			int balance = account.getBalance() + amount;
			// ITEC 4020 use the setBalance method on the account object (it is of type AccountEntry)
			// to set the new balance
			account.setBalance(balance);
			
			
	
				
			// ITEC 4020 Update database with the information stored in the transient object 
			// "account"
			try {
				/*
				 * ITEC 4020 Use the method updateAccountInfo to update the contents of 
				 * the DB
				 */
				database.updateAccountInfo(account);
				// ITEC 4020 set teh value of the "result" variable to the new balance
				result = balance;
			} catch (AccountNotFound e) {
				System.out.println("Invalid account type");
				return null;
				
			}
			/* ITEC 4020 
			 * Return the transient object "account"
			 */
			return account;
		    }
	    return account;
	}
	    
	    	
}
