package transactions;


import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import DataBase.AccountEntry;

/*
 * ITEC 4020 TO IMPLEMENT. This is the twin class of the RestDeposit you already have
 */

@Path("/withdrawal")
public class RestWithdrawal {
	@GET
	@Path("/query")
	public Response DoRestWithdrawal(
			@QueryParam("cardNumber") Integer cardNo  , 
			@QueryParam("pin") Integer pin,
			@QueryParam("accType") Integer accountType,
			@QueryParam("amount") Integer amount) {
	  

			// Implement this. Look the RestDeposit.java class
			AccountEntry result = null;
			
			DBWithdrawal aDBWithdrawal = new DBWithdrawal();
			
			result = aDBWithdrawal.performDBWithdrawal(cardNo, pin, accountType, amount);

			String jsonResult = null;
			
			try {
				
				ObjectMapper mapper = new ObjectMapper();
				jsonResult = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(result);
			} catch (JsonProcessingException e) {
				e.printStackTrace();
			}

			return Response.status(200).entity(jsonResult).build();
	}

}
