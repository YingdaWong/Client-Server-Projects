package transactions;

import DataBase.*;
import DataBase.BankDatabase.AccountNotFound;


/*
 * ITEC 4020 This is the class ti check whether the cardNumber and pin
 * combinatin given by the user on the Login servlet matches the 
 * cardNumber and pin combination in the DB
 * Note: cardNumber and pin parameters are provided by the user
 * Note: the "account" variable contains the account details obtained by the DB
 * using the getAcountInfo method. So the account.getCardNumber() and the 
 * account.getPin() values are the ones coming form the DB. The "if" statement 
 * checks whetehr the user provided cardNumebr and pin match the one that are on the DB
 * if yes, the return true else false
 */

public class DBCredentialsChecker {
	
	public Boolean performDBCredentialsCheck(int cardNumber, int accountType, int pin) {
		AccountEntry account = null;   
        BankDatabase database = new BankDatabase();
        
		try {
			account = database.getAccountInfo(cardNumber, accountType);

	        if(account == null) {
	        	return false;
	        }
	        
	        if(account.getCardNumber() == cardNumber && account.getPin() == pin)
	        	return true;
	        else
	        	return false;
	        			
	        
		} catch (AccountNotFound e) {
			System.out.println("Invalid account type");
			return false;
		}

	}
}
