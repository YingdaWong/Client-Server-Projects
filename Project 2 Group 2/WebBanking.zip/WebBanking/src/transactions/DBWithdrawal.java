package transactions;


import DataBase.*;
import DataBase.BankDatabase.AccountNotFound;

public class DBWithdrawal {
	
	BankDatabase database = new BankDatabase();
	boolean status = false;
	
	public AccountEntry performDBWithdrawal(int cardNumber, int pin, int accountType, int amount) {

		
		/*
		 * ITEC 4020 YOU WRITE THIS 
		 * MAKE SURE YOU CHECK THAT THE amount <= of the balance field in the account
		 * object you get when you will call the getAccountInfo method (see 
		 * performDBDeposit method in the DBDeposit
		 *
		 */
	
        AccountEntry account = null;
		int result = -1;
        BankDatabase database = new BankDatabase();
        DBCredentialsChecker aChecker = new DBCredentialsChecker();
        Boolean checkValue = false;
        
        // Set the value of the account variable using the getAccountInfo method 
		
		try {
			account = database.getAccountInfo(cardNumber, accountType);

		} catch (AccountNotFound e) {
			System.out.println("Invalid account type");
			return null;
		}
		
		// if the amount is > of the balance of the account (i.e. account.getBalance() ) 
		// print "Insufficient available balance" and return null
		checkValue = aChecker.performDBCredentialsCheck(cardNumber, accountType, pin);
		
	if(checkValue) {
		
		if(account.getBalance() < amount) {
			System.out.println("Insufficient available balance");
			return null;
		} else {
		// Renew balance
		int balance = account.getBalance() - amount;
		account.setBalance(balance);
		
	
		// Update database using the updateAccountInfo method on the database variable
		try {
			
			database.updateAccountInfo(account);
			result = balance;
			
		} catch (AccountNotFound e) {
			System.out.println("Invalid account type");
			return null;
		}

		return account;
		}
	}
	
	return account;
	
	}

}
